log_level          :info
log_location       STDOUT
verbose_logging    false
node_name          "impetus-d808-another"
ssl_verify_mode    :verify_none
chef_server_url    "https://api.opscode.com/organizations/impetus-neustar"

validation_client_name "impetus-neustar-validator"
validation_key         "/etc/chef/validation.pem"
client_key             "/etc/chef/client.pem"

encrypted_data_bag_secret "/etc/chef/encrypted_data_bag_secret_key.pem"


file_cache_path    "/var/chef/cache"
file_backup_path   "/var/chef/backup"

http_proxy nil
http_proxy_user nil
http_proxy_pass nil
https_proxy nil
https_proxy_user nil
https_proxy_pass nil
no_proxy nil

pid_file           "/var/run/chef/chef-client.pid"

Mixlib::Log::Formatter.show_time = true


